(() => {
  const slides = Array.from(document.querySelectorAll(".slide"));
  const slidesTrack = document.getElementById("slides");
  const counter = document.getElementById("slideCounter");
  const dotsWrap = document.getElementById("slideDots");
  const prev = document.getElementById("prevSlide");
  const next = document.getElementById("nextSlide");
  let current = 0;

  slides.forEach((slide, index) => {
    const dot = document.createElement("button");
    dot.type = "button";
    dot.setAttribute("aria-label", `Mostrar imagen ${index + 1}`);
    dot.addEventListener("click", () => showSlide(index));
    dotsWrap.appendChild(dot);
  });
  const dots = Array.from(dotsWrap.querySelectorAll("button"));

  function showSlide(index) {
    current = (index + slides.length) % slides.length;
    slidesTrack.style.transform = `translateX(-${current * 100}%)`;
    slides.forEach((slide, i) => slide.classList.toggle("active", i === current));
    dots.forEach((dot, i) => {
      dot.classList.toggle("active", i === current);
      dot.setAttribute("aria-current", i === current ? "true" : "false");
    });
    counter.textContent = `${String(current + 1).padStart(2, "0")} / ${String(slides.length).padStart(2, "0")}`;
  }
  prev.addEventListener("click", () => showSlide(current - 1));
  next.addEventListener("click", () => showSlide(current + 1));
  document.addEventListener("keydown", event => {
    if (event.key === "ArrowLeft") showSlide(current - 1);
    if (event.key === "ArrowRight") showSlide(current + 1);
  });
  let startX = null;
  slidesTrack.addEventListener("touchstart", e => { startX = e.changedTouches[0].screenX; }, {passive:true});
  slidesTrack.addEventListener("touchend", e => {
    if (startX === null) return;
    const delta = e.changedTouches[0].screenX - startX;
    if (Math.abs(delta) > 45) showSlide(current + (delta < 0 ? 1 : -1));
    startX = null;
  }, {passive:true});
  showSlide(0);

  const menuToggle = document.getElementById("menuToggle");
  const nav = document.getElementById("mainNav");
  menuToggle.addEventListener("click", () => {
    const opened = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(opened));
    menuToggle.setAttribute("aria-label", opened ? "Cerrar menú" : "Abrir menú");
  });
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  }));

  // Audio instrumental sintetizado en el navegador; no necesita descargar canciones.
  // Por políticas de los navegadores, solo empieza después de pulsar el botón.
  const audioToggle = document.getElementById("audioToggle");
  const audioStatus = document.getElementById("audioStatus");
  const volume = document.getElementById("volume");
  const muteToggle = document.getElementById("muteToggle");
  let audioContext = null, master = null, timer = null, playing = false, muted = false, step = 0;
  const notes = [261.63,329.63,392,329.63,293.66,349.23,440,392,261.63,329.63,392,523.25,440,392,329.63,293.66];

  function playNote(freq, startAt, duration, type="sine", gainValue=.12) {
    if (!audioContext || !master) return;
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, startAt);
    gain.gain.setValueAtTime(0.0001, startAt);
    gain.gain.exponentialRampToValueAtTime(gainValue, startAt + .04);
    gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration);
    osc.connect(gain); gain.connect(master);
    osc.start(startAt); osc.stop(startAt + duration + .03);
  }
  function beat() {
    if (!audioContext) return;
    const t = audioContext.currentTime;
    const melody = notes[step % notes.length];
    playNote(melody, t, .45, "triangle", .16);
    playNote(melody / 2, t, .72, "sine", .07);
    if (step % 4 === 0) playNote(130.81, t, .2, "sine", .10);
    step++;
  }
  function updateVolume() {
    if (master) master.gain.value = muted ? 0 : Number(volume.value) / 100 * .45;
  }
  async function startAudio() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) { audioStatus.textContent = "Audio no compatible con este navegador"; return; }
    if (!audioContext) {
      audioContext = new AudioCtx();
      master = audioContext.createGain();
      master.connect(audioContext.destination);
    }
    await audioContext.resume();
    updateVolume();
    beat();
    timer = window.setInterval(beat, 430);
    playing = true;
    audioToggle.textContent = "Ⅱ";
    audioToggle.setAttribute("aria-label", "Pausar música");
    audioStatus.textContent = "Instrumental generado en tu navegador";
  }
  function stopAudio() {
    if (timer) window.clearInterval(timer);
    timer = null; playing = false;
    if (audioContext) audioContext.suspend();
    audioToggle.textContent = "▶";
    audioToggle.setAttribute("aria-label", "Reproducir música");
    audioStatus.textContent = "Música pausada";
  }
  audioToggle.addEventListener("click", () => {
    if (playing) stopAudio();
    else startAudio().catch(() => { audioStatus.textContent = "No se pudo iniciar el audio"; });
  });
  volume.addEventListener("input", updateVolume);
  muteToggle.addEventListener("click", () => {
    muted = !muted;
    muteToggle.textContent = muted ? "×" : "♪";
    muteToggle.setAttribute("aria-label", muted ? "Activar sonido" : "Silenciar");
    updateVolume();
  });
})();