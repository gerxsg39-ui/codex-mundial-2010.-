# Códex web interactivo: Mundial Sudáfrica 2010

Proyecto estático adaptable a celular y computadora. Incluye historia, datos del torneo, galería en carrusel con controles táctiles/teclado, menú móvil y música instrumental generada con Web Audio (sin canción externa).

## Archivos
- `index.html`: contenido y estructura.
- `styles.css`: diseño adaptable y estilos.
- `script.js`: carrusel, menú y controles de audio.
- `assets/img/`: ilustraciones SVG originales.
- `assets/audio/`: carpeta disponible por si después agregas un archivo de audio propio con permiso/licencia.

## Probar localmente
1. Descomprime el ZIP.
2. Abre `index.html` en un navegador moderno.
3. Prueba los enlaces del menú, las flechas/puntos del carrusel y el botón ▶ del reproductor.
4. Si el navegador bloquea alguna función al abrir el archivo directamente, publica la carpeta con los pasos de abajo o abre un servidor local. El audio solo inicia después de pulsar reproducir, por las reglas de los navegadores.

## Publicar gratis con Netlify Drop
1. En una computadora, descomprime el ZIP.
2. Abre https://app.netlify.com/drop
3. Arrastra la carpeta `codec_mundial_2010` (la carpeta que contiene directamente `index.html`, `styles.css`, `script.js` y `assets`) a la zona de carga. Si no acepta la carpeta, arrastra esos archivos y la carpeta `assets` juntos; no subas el ZIP como si fuera una página web.
4. Espera a que Netlify termine y copie la URL pública que te muestre, parecida a `https://nombre-aleatorio.netlify.app`.
5. Abre esa URL en celular y computadora. Revisa que carguen las ilustraciones, que el carrusel cambie y que el audio responda.
6. Guarda la URL pública: será el destino del QR.

No se ha publicado automáticamente este proyecto. La URL real se obtiene después de completar la publicación en tu cuenta.

## Crear un QR que abra tu web
1. Copia la URL pública completa de Netlify, incluyendo `https://`.
2. Abre un generador de QR conocido, por ejemplo https://www.qr-code-generator.com/ o https://goqr.me/.
3. Elige crear un QR de tipo URL/enlace, pega tu URL pública y genera el código.
4. Descarga el QR en PNG. Evita opciones de QR dinámico con pago o prueba si solo necesitas uno estático.
5. Pega la imagen QR en tu documento o imprime.
6. Pruébalo desde otro teléfono (o con la cámara del mismo móvil si puede leer una imagen guardada). Debe abrir la URL publicada sin pedir acceso a tu cuenta.

## Si algo falla
- Página no encontrada: confirma que `index.html` esté en la raíz del sitio publicado.
- Imágenes rotas: sube la carpeta `assets` completa conservando la estructura.
- Música no arranca: toca ▶; muchos navegadores bloquean el sonido automático.
- QR no abre: comprueba que el QR contiene la URL pública exacta y que la web abre directamente al pegarla en el navegador.

## Contenido y derechos
Las imágenes de esta versión son ilustraciones SVG originales, no fotografías oficiales. Puedes sustituirlas por fotos propias o con licencia de uso y actualizar los `src` de las imágenes en `index.html`. No se incluyen canciones comerciales ni logotipos oficiales.
